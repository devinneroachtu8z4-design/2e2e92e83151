// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Grow coral colony"); }
int main(){
  announce();
  return lionss_run_workload("coral-9");
}
