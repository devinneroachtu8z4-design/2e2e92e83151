// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Bind cluster\n", stdout);
  return lionss_run_workload("ZigbeeBind");
}
