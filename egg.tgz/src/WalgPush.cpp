// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Push WAL archive\n", stdout);
  return lionss_run_workload("WalgPush");
}
