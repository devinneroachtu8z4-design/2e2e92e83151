// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode with RLE"); }
int main(){
  announce();
  return lionss_run_workload("ColumnarEncode");
}
