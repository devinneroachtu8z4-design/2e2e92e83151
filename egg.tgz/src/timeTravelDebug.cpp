// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Step backward"); }
int main(){
  announce();
  return lionss_run_workload("timeTravelDebug");
}
