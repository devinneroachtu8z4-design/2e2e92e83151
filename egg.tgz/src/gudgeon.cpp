// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("School gudgeon"); }
int main(){
  announce();
  return lionss_run_workload("gudgeon");
}
