// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Till clayfield\n", stdout);
  return lionss_run_workload("clayfield");
}
